<?php

namespace GsbFrais\ConnexionBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class GestionMdpControllerTest extends WebTestCase
{
}
