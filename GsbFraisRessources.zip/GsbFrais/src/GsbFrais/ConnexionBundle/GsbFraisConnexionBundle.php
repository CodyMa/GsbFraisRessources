<?php

namespace GsbFrais\ConnexionBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GsbFraisConnexionBundle extends Bundle
{
}
