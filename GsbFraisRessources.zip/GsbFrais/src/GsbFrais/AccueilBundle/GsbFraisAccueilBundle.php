<?php

namespace GsbFrais\AccueilBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GsbFraisAccueilBundle extends Bundle
{
}
