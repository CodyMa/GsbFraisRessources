<?php

namespace GsbFrais\AccueilBundle\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;

class DefaultController extends Controller
{
    public function indexAction()
    {
        return $this->render('accueil/accueil.html.twig');
    }
}
