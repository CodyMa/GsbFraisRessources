<?php

namespace GsbFrais\ProfilBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class GsbFraisProfilBundle extends Bundle
{
}
