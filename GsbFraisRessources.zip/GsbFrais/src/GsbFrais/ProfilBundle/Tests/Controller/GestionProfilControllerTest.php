<?php

namespace GsbFrais\ProfilBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class GestionProfilControllerTest extends WebTestCase
{
}
