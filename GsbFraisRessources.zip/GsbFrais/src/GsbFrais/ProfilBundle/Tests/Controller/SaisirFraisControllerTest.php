<?php

namespace GsbFrais\ProfilBundle\Tests\Controller;

use Symfony\Bundle\FrameworkBundle\Test\WebTestCase;

class SaisirFraisControllerTest extends WebTestCase
{

}
