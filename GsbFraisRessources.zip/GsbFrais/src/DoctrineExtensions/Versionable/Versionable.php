<?php
namespace DoctrineExtensions\Versionable;

interface Versionable
{

}